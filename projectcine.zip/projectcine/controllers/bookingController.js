// controllers/bookingController.js
const bookingService = require('../services/bookingService');

class BookingController {
  async getAllBookings(req, res) {
    try {
      const bookings = await bookingService.getAllBookings();
      res.json(bookings);
    } catch (error) {
      console.error('Error fetching bookings:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  async getBookingById(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const booking = await bookingService.getBookingById(id);
      if (!booking) {
        return res.status(404).json({ message: 'Booking not found' });
      }
      res.json(booking);
    } catch (error) {
      console.error('Error fetching booking:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  async createBooking(req, res) {
    try {
      const { id, movid, usid, date, price } = req.body;
      const newBooking = await bookingService.createBooking({ id, movid, usid, date, price });
      res.status(201).json(newBooking);
    } catch (error) {
      console.error('Error creating booking:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  async updateBooking(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const { movid, usid, date, price } = req.body;
      const success = await bookingService.updateBooking(id, { movid, usid, date, price });
      if (!success) {
        return res.status(404).json({ message: 'Booking not found or no changes made' });
      }
      res.json({ message: 'Booking updated successfully' });
    } catch (error) {
      console.error('Error updating booking:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  async deleteBooking(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await bookingService.deleteBooking(id);
      if (!success) {
        return res.status(404).json({ message: 'Booking not found' });
      }
      res.json({ message: 'Booking deleted successfully' });
    } catch (error) {
      console.error('Error deleting booking:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
}

module.exports = new BookingController();
