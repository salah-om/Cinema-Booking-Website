// controllers/userController.js
const userService = require('../services/userService');

class UserController {
    /*
    -----------------------------------------------------------------------
      Purpose: Retrieves all users.
      Parameters: the req is the request object & the res is the response 
      object sending JSON data.
      Postcondition: A JSON array of users or an error message.
    -----------------------------------------------------------------------
    */
  async getAllUsers(req, res) {
    try {
      const users = await userService.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error('Error fetching users:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
    /*
    -----------------------------------------------------------------------
      Purpose: Retrieves a user by ID.
      Parameters: The req is the request object with a user ID & the 
      res is the response object sending JSON data.
      Postcondition: Requested user data for specific ID or error message.
    -----------------------------------------------------------------------
    */
  async getUserById(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const user = await userService.getUserById(id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      console.error('Error fetching user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
    /*
    -----------------------------------------------------------------------
      Purpose: Creates a new user.
      Parameters: The req is the request object with user data in the body
      & the res is the response object sending JSON data.
      Postcondition: Creates the user with its data or error message.
    -----------------------------------------------------------------------
    */
  async createUser(req, res) {
    try {
      const { id, fname, lname, email, pass } = req.body;
      const newUser = await userService.createUser({ id, fname, lname, email, pass });
      res.status(201).json(newUser);
    } catch (error) {
      console.error('Error creating user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
    /*
    -----------------------------------------------------------------------
      Purpose: Updates an existing user by its ID.
      Parameters: The req is the request object with user ID and updated 
      data in the body & the res is the response object sending JSON data.
      Postcondition: Updates user and responds with success message or 
      error message if user was not found or changed.
    -----------------------------------------------------------------------
    */
  async updateUser(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const { fname, lname, email } = req.body;
      const success = await userService.updateUser(id, { fname, lname, email });
      if (!success) {
        return res.status(404).json({ message: 'User not found or no changes made' });
      }
      res.json({ message: 'User updated successfully' });
    } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
    /*
    -----------------------------------------------------------------------
      Purpose: Deletes a user by its ID.
      Parameters: The req is the request object with user ID & the res is 
      the response object sending JSON data.
      Postcondition: Deletes the user and responds with success message or 
      error message if user was not found or deleted.
    -----------------------------------------------------------------------
    */
  async deleteUser(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await userService.deleteUser(id);
      if (!success) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      console.error('Error deleting user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
}

module.exports = new UserController();
