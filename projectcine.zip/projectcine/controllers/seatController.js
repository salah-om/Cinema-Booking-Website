// controllers/seatController.js
const seatService = require('../services/seatService');

class SeatController {
    /*
    -----------------------------------------------------------------------
      Purpose: Retrieves all seats.
      Parameters: the req is the request object & the res is the response 
      object sending JSON data.
      Postcondition: A JSON array of seats or an error message.
    -----------------------------------------------------------------------
    */
  async getAllSeats(req, res) {
    try {
      const seats = await seatService.getAllSeats();
      res.json(seats);
    } catch (error) {
      console.error('Error fetching seats:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

    /*
    -----------------------------------------------------------------------
      Purpose: Retrieves a seat by ID.
      Parameters: The req is the request object with a seat ID & the 
      res is the response object sending JSON data.
      Postcondition: Requested seat data for specific ID or error message.
    -----------------------------------------------------------------------
    */
  async getSeatById(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const seat = await seatService.getSeatById(id);
      if (!seat) {
        return res.status(404).json({ message: 'Seat not found' });
      }
      res.json(seat);
    } catch (error) {
      console.error('Error fetching seat:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

    /*
    -----------------------------------------------------------------------
      Purpose: Creates a new seat.
      Parameters: The req is the request object with seat data in the body
      & the res is the response object sending JSON data.
      Postcondition: Creates the seat with its data or error message.
    -----------------------------------------------------------------------
    */
  async createSeat(req, res) {
    try {
      const { id, bookid, status, number } = req.body;
      const newSeat = await seatService.createSeat({ id, bookid, status, number });
      res.status(201).json(newSeat);
    } catch (error) {
      console.error('Error creating seat:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

    /*
    -----------------------------------------------------------------------
      Purpose: Updates an existing seat by its ID.
      Parameters: The req is the request object with seat ID and updated 
      data in the body & the res is the response object sending JSON data.
      Postcondition: Updates seat and responds with success message or 
      error message if seat was not found or changed.
    -----------------------------------------------------------------------
    */
  async updateSeat(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const { bookid, status, number } = req.body;
      const success = await seatService.updateSeat(id, { bookid, status, number });
      if (!success) {
        return res.status(404).json({ message: 'Seat not found or no changes made' });
      }
      res.json({ message: 'Seat updated successfully' });
    } catch (error) {
      console.error('Error updating seat:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
    /*
    -----------------------------------------------------------------------
      Purpose: Deletes a seat by its ID.
      Parameters: The req is the request object with seat ID & the res is 
      the response object sending JSON data.
      Postcondition: Deletes the seat and responds with success message or 
      error message if seat was not found or deleted.
    -----------------------------------------------------------------------
    */  
  async deleteSeat(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await seatService.deleteSeat(id);
      if (!success) {
        return res.status(404).json({ message: 'Seat not found' });
      }
      res.json({ message: 'Seat deleted successfully' });
    } catch (error) {
      console.error('Error deleting seat:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
}

module.exports = new SeatController();
