// controllers/seatController.js
const seatService = require('../services/seatService');

class SeatController {
  async getAllSeats(req, res) {
    try {
      const seats = await seatService.getAllSeats();
      res.json(seats);
    } catch (error) {
      console.error('Error fetching seats:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  async getSeatById(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const seat = await seatService.getSeatById(id);
      if (!seat) {
        return res.status(404).json({ message: 'Seat not found' });
      }
      res.json(seat);
    } catch (error) {
      console.error('Error fetching seat:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  async createSeat(req, res) {
    try {
      const { id, bookid, status, number } = req.body;
      const newSeat = await seatService.createSeat({ id, bookid, status, number });
      res.status(201).json(newSeat);
    } catch (error) {
      console.error('Error creating seat:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  async updateSeat(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const { bookid, status, number } = req.body;
      const success = await seatService.updateSeat(id, { bookid, status, number });
      if (!success) {
        return res.status(404).json({ message: 'Seat not found or no changes made' });
      }
      res.json({ message: 'Seat updated successfully' });
    } catch (error) {
      console.error('Error updating seat:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  async deleteSeat(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await seatService.deleteSeat(id);
      if (!success) {
        return res.status(404).json({ message: 'Seat not found' });
      }
      res.json({ message: 'Seat deleted successfully' });
    } catch (error) {
      console.error('Error deleting seat:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
}

module.exports = new SeatController();
