// services/userService.js
const { initDB } = require('../config/database');
const User = require('../models/userModel');

class UserService {
  constructor() {
    this.pool = null;
    this.init();
  }

  async init() {
    this.pool = await initDB();
  }

  async getAllUsers() {
    const [rows] = await this.pool.query('SELECT * FROM users');
    return rows.map(User.fromRow);
  }

  async getUserById(id) {
    const [rows] = await this.pool.query('SELECT * FROM users WHERE user_id = ?', [id]);
    if (rows.length === 0) return null;
    return User.fromRow(rows[0]);
  }

  async createUser(userData) {
    const { fname, lname, email, pass } = userData;
    const [result] = await this.pool.query(
      'INSERT INTO users (user_fname, user_lname, user_email, user_pass) VALUES (?, ?, ?, ?)',
      [fname, lname, email, pass]
    );
    const insertedUser = new User(result.insertId, fname, lname, email, pass);
    return insertedUser;
  }

  async updateUser(id, userData) {
    const { fname, lname, email } = userData;
    const [result] = await this.pool.query(
      'UPDATE users SET user_fname = ?, user_lname = ?, user_email = ? WHERE user_id = ?',
      [fname, lname, email, id]
    );
    return result.affectedRows > 0;
  }

  async deleteUser(id) {
    const [result] = await this.pool.query('DELETE FROM users WHERE user_id = ?', [id]);
    return result.affectedRows > 0;
  }
}

module.exports = new UserService();
