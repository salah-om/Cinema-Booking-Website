// services/movieService.js
const { initDB } = require('../config/database');
const Movie = require('../models/movieModel');

class MovieService {
  constructor() {
    this.pool = null;
    this.init();
  }

  async init() {
    this.pool = await initDB();
  }

  async getAllMovies() {
    const [rows] = await this.pool.query('SELECT * FROM movies');
    return rows.map(Movie.fromRow);
  }

  async getMovieById(id) {
    const [rows] = await this.pool.query('SELECT * FROM movies WHERE movie_id = ?', [id]);
    if (rows.length === 0) return null;
    return Movie.fromRow(rows[0]);
  }

  async createMovie(movieData) {
    const { title, description, genre, duration, release, stars, screening, hallno, rating, lang } = movieData;
    const [result] = await this.pool.query(
      'INSERT INTO movies (movie_title, movie_desc, movie_genre, movie_duration, movie_release, movie_stars, movie_screeningtime, movie_hallno, movie_rating, movie_lang) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [title, description, genre, duration, release, stars, screening, hallno, rating, lang]
    );
    const insertedMovie = new Movie(result.insertId, title, description, genre, duration, release, stars, screening, hallno, rating, lang);
    return insertedMovie;
  }

  async updateMovie(id, movieData) {
    const { title, description, genre, duration, release, stars, screening, hallno, rating, lang } = movieData;
    const [result] = await this.pool.query(
      'UPDATE movies SET movie_title = ?, movie_desc = ?, movie_genre = ?, movie_duration = ?, movie_release = ?, movie_stars = ?, movie_screeningtime = ?, movie_hallno = ?, movie_rating = ?, movie_lang = ?',
      [title, description, genre, duration, release, stars, screening, hallno, rating, lang, id]
    );
    return result.affectedRows > 0;
  }

  async deleteMovie(id) {
    const [result] = await this.pool.query('DELETE FROM movies WHERE movie_id = ?', [id]);
    return result.affectedRows > 0;
  }
}

module.exports = new MovieService();
