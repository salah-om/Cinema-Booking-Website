// services/bookingService.js
const { initDB } = require('../config/database');
const Booking = require('../models/bookingModel');

class BookingService {
  constructor() {
    this.pool = null;
    this.init();
  }

  async init() {
    this.pool = await initDB();
  }

  async getAllBookings() {
    const [rows] = await this.pool.query('SELECT * FROM bookings');
    return rows.map(Booking.fromRow);
  }

  async getBookingById(id) {
    const [rows] = await this.pool.query('SELECT * FROM bookings WHERE booking_id = ?', [id]);
    if (rows.length === 0) return null;
    return Booking.fromRow(rows[0]);
  }

  async createBooking(bookingData) {
    const { movid, usid, date, price } = bookingData;
    const [result] = await this.pool.query(
      'INSERT INTO bookings (movie_id, user_id, booking_date, booking_price) VALUES (?, ?, ?, ?)',
      [movid, usid, date, price]
    );
    const insertedBooking = new Booking(result.insertId, movid, usid, date, price);
    return insertedBooking;
  }

  async updateBooking(id, bookingData) {
    const { movid, usid, date, price } = bookingData;
    const [result] = await this.pool.query(
      'UPDATE bookings SET movie_id = ?, user_id = ?, booking_date = ?, booking_price = ? WHERE booking_id = ?',
      [movid, usid, date, price, id]
    );
    return result.affectedRows > 0;
  }

  async deleteBooking(id) {
    const [result] = await this.pool.query('DELETE FROM bookings WHERE booking_id = ?', [id]);
    return result.affectedRows > 0;
  }
}

module.exports = new BookingService();
