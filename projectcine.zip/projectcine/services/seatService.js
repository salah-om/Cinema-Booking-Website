// services/seatService.js
const { initDB } = require('../config/database');
const Seat = require('../models/seatModel');

class SeatService {
  constructor() {
    this.pool = null;
    this.init();
  }

  async init() {
    this.pool = await initDB();
  }

  async getAllSeats() {
    const [rows] = await this.pool.query('SELECT * FROM seats');
    return rows.map(Seat.fromRow);
  }

  async getSeatById(id) {
    const [rows] = await this.pool.query('SELECT * FROM seats WHERE seat_id = ?', [id]);
    if (rows.length === 0) return null;
    return Seat.fromRow(rows[0]);
  }

  async createSeat(seatData) {
    const { bookid, status, number } = seatData;
    const [result] = await this.pool.query(
      'INSERT INTO seats (seat_id, booking_id, seat_status, seat_no) VALUES (?, ?, ?, ?)',
      [bookid, status, number]
    );
    const insertedSeat = new Seat(result.insertId, bookid, status, number);
    return insertedSeat;
  }

  async updateSeat(id, seatData) {
    const { bookid, status, number } = seatData;
    const [result] = await this.pool.query(
      'UPDATE seats SET booking_id = ?, seat_status = ?, seat_no = ? WHERE seat_id = ?',
      [bookid, status, number, id]
    );
    return result.affectedRows > 0;
  }

  async deleteSeat(id) {
    const [result] = await this.pool.query('DELETE FROM seats WHERE seat_id = ?', [id]);
    return result.affectedRows > 0;
  }
}

module.exports = new SeatService();
