// routes/seatRoutes.js
const express = require('express');
const seatController = require('../controllers/seatController');
const { validateSeat, validateSeatId } = require('../validators/seatDTO');

const router = express.Router();

// Define routes
router.get('/', (req, res) => seatController.getAllSeats(req, res));
router.get('/:id', validateSeatId, (req, res) => seatController.getSeatById(req, res));
router.post('/', validateSeat, (req, res) => seatController.createSeat(req, res));
router.put('/:id', [validateSeatId, validateSeat], (req, res) => seatController.updateSeat(req, res));
router.delete('/:id', validateSeatId, (req, res) => seatController.deleteSeat(req, res));

module.exports = router;
