// routes/movieRoutes.js
const express = require('express');
const movieController = require('../controllers/movieController');
const { validateMovie, validateMovieId } = require('../validators/movieDTO');

const router = express.Router();

// Define routes
router.get('/', (req, res) => movieController.getAllMovies(req, res));
router.get('/:id', validateMovieId, (req, res) => movieController.getMovieById(req, res));
router.post('/', validateMovie, (req, res) => movieController.createMovie(req, res));
router.put('/:id', [validateMovieId, validateMovie], (req, res) => movieController.updateMovie(req, res));
router.delete('/:id', validateMovieId, (req, res) => movieController.deleteMovie(req, res));

module.exports = router;
