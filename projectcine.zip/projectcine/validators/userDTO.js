// validators/userValidator.js
const { body, param, validationResult } = require('express-validator');

const validateUser = [
  body('fname')
    .isString()
    .withMessage('First Name must be a string')
    .notEmpty()
    .withMessage('First Name is required'),
  body('lname')
    .isString()
    .withMessage('Last Name must be a string')
    .notEmpty()
    .withMessage('Last Name is required'),
  body('email')
    .isEmail()
    .withMessage('Email must be valid')
    .notEmpty()
    .withMessage('Email is required'),
  body('pass')
    .isString()
    .withMessage('Password must be a string')
    .notEmpty()
    .withMessage('Password is required'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  }
];

const validateUserId = [
  param('id').isInt().withMessage('ID must be an integer'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  }
];

module.exports = {
  validateUser,
  validateUserId
};
